package com.example.service

import android.annotation.SuppressLint
import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.IBinder
import android.provider.Settings
import android.util.TypedValue
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import com.example.MainActivity
import com.example.R
import com.example.data.model.RecordingSnapshot
import com.example.data.model.RecordingStatus
import com.example.data.repository.SettingsRepository
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch

class FloatingBubbleService : Service() {

    companion object {
        const val ACTION_SHOW = "com.example.anexus.ACTION_SHOW_BUBBLE"
        const val ACTION_HIDE = "com.example.anexus.ACTION_HIDE_BUBBLE"
    }

    private var windowManager: WindowManager? = null
    private var bubbleContainer: FrameLayout? = null
    private var layoutParams: WindowManager.LayoutParams? = null

    private var isExpanded = false
    private val serviceScope = CoroutineScope(Dispatchers.Main + Job())
    private var stateJob: Job? = null

    private var initialX = 0
    private var initialY = 0
    private var initialTouchX = 0f
    private var initialTouchY = 0f

    // UI elements inside bubble
    private var timerTextView: TextView? = null
    private var pauseResumeIcon: ImageView? = null
    private var expandedControlsLayout: LinearLayout? = null
    private var collapsedDot: View? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        windowManager = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        observeRecordingState()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val action = intent?.action ?: return START_NOT_STICKY

        when (action) {
            ACTION_SHOW -> {
                if (Settings.canDrawOverlays(this)) {
                    showBubble()
                }
            }
            ACTION_HIDE -> hideBubble()
        }

        return START_NOT_STICKY
    }

    private fun observeRecordingState() {
        stateJob?.cancel()
        stateJob = serviceScope.launch {
            ScreenCaptureService.recordingState.collectLatest { snapshot ->
                updateBubbleUi(snapshot)
            }
        }
    }

    private fun updateBubbleUi(snapshot: RecordingSnapshot) {
        if (!snapshot.isRecordingActive && snapshot.status != RecordingStatus.STOPPING) {
            hideBubble()
            return
        }

        timerTextView?.text = snapshot.formattedElapsedTime

        if (snapshot.status == RecordingStatus.PAUSED) {
            pauseResumeIcon?.setImageResource(android.R.drawable.ic_media_play)
            collapsedDot?.setBackgroundColor(Color.parseColor("#F59E0B")) // Amber
        } else {
            pauseResumeIcon?.setImageResource(android.R.drawable.ic_media_pause)
            collapsedDot?.setBackgroundColor(Color.parseColor("#EF4444")) // Glowing Red
        }
    }

    @SuppressLint("ClickableViewAccessibility")
    private fun showBubble() {
        if (bubbleContainer != null) return

        val settingsRepo = SettingsRepository(this)
        val config = settingsRepo.getConfig()

        val windowType = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            @Suppress("DEPRECATION")
            WindowManager.LayoutParams.TYPE_PHONE
        }

        var flags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS

        // CRITICAL REQUIREMENT #5:
        // Set FLAG_SECURE on the overlay window so that Android's SurfaceFlinger and MediaProjection
        // exclude this window from being captured in the recorded video!
        if (config.secureInvisibleBubble) {
            flags = flags or WindowManager.LayoutParams.FLAG_SECURE
        }

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            windowType,
            flags,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 30
            y = 300
        }

        layoutParams = params
        val root = createBubbleView()
        bubbleContainer = root

        root.setOnTouchListener { _, event ->
            handleTouch(event)
        }

        try {
            windowManager?.addView(root, params)
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    private fun handleTouch(event: MotionEvent): Boolean {
        val params = layoutParams ?: return false
        val root = bubbleContainer ?: return false

        when (event.action) {
            MotionEvent.ACTION_DOWN -> {
                initialX = params.x
                initialY = params.y
                initialTouchX = event.rawX
                initialTouchY = event.rawY
                return true
            }
            MotionEvent.ACTION_MOVE -> {
                val dx = (event.rawX - initialTouchX).toInt()
                val dy = (event.rawY - initialTouchY).toInt()
                params.x = initialX + dx
                params.y = initialY + dy
                try {
                    windowManager?.updateViewLayout(root, params)
                } catch (e: Exception) {
                    e.printStackTrace()
                }
                return true
            }
            MotionEvent.ACTION_UP -> {
                val diffX = Math.abs(event.rawX - initialTouchX)
                val diffY = Math.abs(event.rawY - initialTouchY)
                if (diffX < 15 && diffY < 15) {
                    // Tap detected -> toggle expanded controls
                    toggleExpanded()
                }
                return true
            }
        }
        return false
    }

    private fun toggleExpanded() {
        isExpanded = !isExpanded
        expandedControlsLayout?.visibility = if (isExpanded) View.VISIBLE else View.GONE
        try {
            windowManager?.updateViewLayout(bubbleContainer, layoutParams)
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    private fun createBubbleView(): FrameLayout {
        val dpToPx = { dp: Int ->
            TypedValue.applyDimension(
                TypedValue.COMPLEX_UNIT_DIP,
                dp.toFloat(),
                resources.displayMetrics
            ).toInt()
        }

        val container = FrameLayout(this)

        val mainLayout = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dpToPx(10), dpToPx(8), dpToPx(10), dpToPx(8))

            val bg = GradientDrawable().apply {
                setColor(Color.parseColor("#E60D0F18")) // 90% opacity deep dark
                cornerRadius = dpToPx(24).toFloat()
                setStroke(dpToPx(1), Color.parseColor("#4C8B5CF6")) // subtle neon purple border
            }
            background = bg
            elevation = dpToPx(8).toFloat()
        }

        // Collapsed status indicator dot
        collapsedDot = View(this).apply {
            val dotBg = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(Color.parseColor("#EF4444"))
            }
            background = dotBg
            val dotSize = dpToPx(10)
            layoutParams = LinearLayout.LayoutParams(dotSize, dotSize).apply {
                marginEnd = dpToPx(8)
            }
        }
        mainLayout.addView(collapsedDot)

        // Timer text
        timerTextView = TextView(this).apply {
            text = "00:00:00"
            setTextColor(Color.WHITE)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f)
            setTypeface(android.graphics.Typeface.MONOSPACE, android.graphics.Typeface.BOLD)
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply {
                marginEnd = dpToPx(8)
            }
        }
        mainLayout.addView(timerTextView)

        // Expanded controls container
        expandedControlsLayout = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            visibility = View.GONE
        }

        // Pause / Resume button
        pauseResumeIcon = ImageView(this).apply {
            setImageResource(android.R.drawable.ic_media_pause)
            setColorFilter(Color.WHITE)
            setPadding(dpToPx(6), dpToPx(6), dpToPx(6), dpToPx(6))
            val btnBg = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(Color.parseColor("#2A314E"))
            }
            background = btnBg
            val size = dpToPx(32)
            layoutParams = LinearLayout.LayoutParams(size, size).apply {
                marginEnd = dpToPx(6)
            }
            setOnClickListener {
                val state = ScreenCaptureService.recordingState.value.status
                val action = if (state == RecordingStatus.PAUSED) {
                    ScreenCaptureService.ACTION_RESUME
                } else {
                    ScreenCaptureService.ACTION_PAUSE
                }
                sendServiceAction(action)
            }
        }
        expandedControlsLayout?.addView(pauseResumeIcon)

        // Stop button
        val stopIcon = ImageView(this).apply {
            setImageResource(android.R.drawable.ic_menu_close_clear_cancel)
            setColorFilter(Color.WHITE)
            setPadding(dpToPx(6), dpToPx(6), dpToPx(6), dpToPx(6))
            val btnBg = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(Color.parseColor("#DC2626")) // Red
            }
            background = btnBg
            val size = dpToPx(32)
            layoutParams = LinearLayout.LayoutParams(size, size).apply {
                marginEnd = dpToPx(6)
            }
            setOnClickListener {
                sendServiceAction(ScreenCaptureService.ACTION_STOP)
            }
        }
        expandedControlsLayout?.addView(stopIcon)

        // App button to bring Anexus to front
        val appIcon = ImageView(this).apply {
            setImageResource(R.drawable.ic_tile_record)
            setColorFilter(Color.parseColor("#A855F7"))
            setPadding(dpToPx(4), dpToPx(4), dpToPx(4), dpToPx(4))
            val size = dpToPx(30)
            layoutParams = LinearLayout.LayoutParams(size, size)
            setOnClickListener {
                val intent = Intent(this@FloatingBubbleService, MainActivity::class.java).apply {
                    flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP
                }
                startActivity(intent)
            }
        }
        expandedControlsLayout?.addView(appIcon)

        mainLayout.addView(expandedControlsLayout)
        container.addView(mainLayout)

        return container
    }

    private fun sendServiceAction(action: String) {
        val intent = Intent(this, ScreenCaptureService::class.java).apply {
            this.action = action
        }
        startService(intent)
    }

    private fun hideBubble() {
        if (bubbleContainer != null) {
            try {
                windowManager?.removeView(bubbleContainer)
            } catch (e: Exception) {
                e.printStackTrace()
            }
            bubbleContainer = null
        }
        stopSelf()
    }

    override fun onDestroy() {
        super.onDestroy()
        stateJob?.cancel()
        hideBubble()
    }
}
